// Name: Alex Kotoka
// Student ID: 11123892
// Project: Multi-question C# Console Application
// Date: August 2025

using System;

namespace AssignmentSolutions.Q3.Warehouse
{
    public class DuplicateItemException : Exception { public DuplicateItemException(string message) : base(message) { } }
    public class ItemNotFoundException : Exception { public ItemNotFoundException(string message) : base(message) { } }
    public class InvalidQuantityException : Exception { public InvalidQuantityException(string message) : base(message) { } }
}
