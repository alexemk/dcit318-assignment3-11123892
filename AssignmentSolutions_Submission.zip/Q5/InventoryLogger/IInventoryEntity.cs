// Name: Alex Kotoka
// Student ID: 11123892
// Project: Multi-question C# Console Application
// Date: August 2025

namespace AssignmentSolutions.Q5.InventoryLogger
{
    public interface IInventoryEntity { int Id { get; } }
}
